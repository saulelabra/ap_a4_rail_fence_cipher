//Saúl Enrique Labra Cruz A01020725
//activity 4 - Rail Fence Cipher

#include "rfc.h"

int main()
{
    ui();

    return 0;
}